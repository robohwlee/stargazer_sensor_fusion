import roslib; roslib.load_manifest('visualization_marker_tutorials')
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray
from std_msgs.msg import String
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from rosgraph_msgs.msg import Clock
import rospy
import math


pf_dict = {}
goal_position = (3, 4)


def lidar_callback(msg):
    count = 0
    MARKERS_MAX = 180

    publisher = rospy.Publisher('repulsive_field_marker', MarkerArray, queue_size=10)

    markerArray = MarkerArray()

    for i, j in enumerate(msg.ranges):
        k = msg.angle_min + i * msg.angle_increment # quaternion z-angle
        if k >= 0:
            l = k * 180 / math.pi # euler z-angle
        else:
            l = -k * 180 / math.pi

        if j != 0: # distance != 0m
            #print("{} degree: {}m".format(l, j))
            pf_dict[i] = j

        marker = Marker()
        marker.header.frame_id = "/base_link"
        marker.type = marker.ARROW
        marker.action = marker.ADD
        
        marker.scale.x = j / 4
        marker.scale.y = 0.05
        marker.scale.z = 0.05

        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 1.0
        marker.color.b = 0.0

        marker.pose.position.x = 0
        marker.pose.position.y = 0
        marker.pose.position.z = 0
        marker.pose.orientation.z = k
        marker.pose.orientation.w = 1.0

        # We add the new marker to the MarkerArray, removing the oldest
        # marker from it when necessary
        if(count > MARKERS_MAX):
            markerArray.markers.pop(0)
 
        markerArray.markers.append(marker)
 
        # Renumber the marker IDs
        id = 0
        for m in markerArray.markers:
            m.id = id
            id += 1
 
        # Publish the MarkerArray
        publisher.publish(markerArray)

        count += 1
 

def odom_callback(msg):
    count = 0
    MARKERS_MAX = 1
    
    publisher = rospy.Publisher('attractive_field_marker', MarkerArray, queue_size=10)

    marker_length = math.sqrt( (goal_position[0] - msg.pose.pose.position.x) ** 2 + (goal_position[1] - msg.pose.pose.position.y) ** 2 ) 


    markerArray = MarkerArray()

    marker = Marker()
    marker.header.frame_id = "/base_footprint"
    marker.type = marker.ARROW
    marker.action = marker.ADD
    
    marker.scale.x = marker_length 
    marker.scale.y = 0.05
    marker.scale.z = 0.05

    marker.color.a = 1.0
    marker.color.r = 1.0
    marker.color.g = 0.0
    marker.color.b = 1.0

    marker.pose.position.x = 0
    marker.pose.position.y = 0
    marker.pose.position.z = 0
    marker.pose.orientation.z = msg.pose.pose.orientation.z
    marker.pose.orientation.w = 1.0

    # We add the new marker to the MarkerArray, removing the oldest
    # marker from it when necessary
    if(count > MARKERS_MAX):
        markerArray.markers.pop(0)

    markerArray.markers.append(marker)

    # Renumber the marker IDs
    id = 0
    for m in markerArray.markers:
        m.id = id
        id += 1

    # Publish the MarkerArray
    publisher.publish(markerArray)

    print("robot position: ({:.2f},{:.2f}) marker_lenght: {:.2f}".format(msg.pose.pose.position.x, msg.pose.pose.position.y, marker_length))

    count += 1


rospy.init_node('register')
rospy.get_rostime()

while not rospy.is_shutdown():


#   sub1 = rospy.Subscriber('/scan', LaserScan, lidar_callback)

   sub2 = rospy.Subscriber('/odom', Odometry, odom_callback)


   rospy.sleep(0.01)